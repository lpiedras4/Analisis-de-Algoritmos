public class Pila extends Lista{

@Override
<T> Node adicionar(T data) {
    Node node = new Node(data);
    if(head==null){
    head=node;
    }else {
        node.next = head;
        head = node;
    }
    return head;
}



    @Override
void imprimir() {
    Node current = head;
    System.out.println("Imprimiendo pila");
    while (current != null) {
        System.out.println(current.data + "\n" + "-");
        current = current.next;
    }
}

@Override
 Node extraer() {
    if(head == null){
        System.out.println("La pila está vacía");
        return null;
    }
    Node  current = head;
    System.out.println("Dato eliminado: " + current.data);
    head = head.next;
    return head;
}




@Override
<T> Object frente() {
    if (head==null){
        System.out.println("La pila esta vacía");
        return null;
    }else{
        return head.data;
    }
}

@Override
<T> Object fondo() {
    return null;
}



    @Override
boolean vacia() {
    if(head==null){
        return true;
    }else{
        return false;
    }

}
}