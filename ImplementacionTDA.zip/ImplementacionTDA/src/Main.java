//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        /*--------------Pila-----------------*/
Pila pila = new Pila();
        System.out.println("Pila vacía " + pila.vacia());
       pila.adicionar(1);
       pila.adicionar(2.8);
       pila.adicionar('a');
       pila.adicionar("Leonardo");
       pila.adicionar(3.1416);
       pila.imprimir();
       pila.extraer();
       pila.imprimir();
        System.out.println("\n"+"Tope de pila: " + pila.frente());
        System.out.println("La pila esta vacía? " + pila.vacia());
        System.out.println();

        /*--------------Cola-----------------*/
Cola cola = new Cola();
//Vacía
        //Adicionar
        //Extraer
        //Fondo
        //Frente
        cola.adicionar(5);
       cola.adicionar("Pancho");
       cola.adicionar('c');
       cola.adicionar(2.34);
       cola.adicionar(3.455678);
       cola.imprimir();
       /*
       cola.extraer();
       cola.imprimir();
       */
        System.out.println("Frente de cola: " + cola.frente());
        System.out.println("Fondo de cola: " + cola.fondo());


    }
}