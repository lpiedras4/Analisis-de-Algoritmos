

public abstract class Lista {
     Node head;
    static class Node <T> {
        T data;
        Node <T> next;
        public Node (T data) {
            this.data=data;
            this.next=null;
        }
    }
    abstract <T> Node adicionar(T data);
    abstract void imprimir();
    abstract Node extraer();
    abstract <T> Object frente();
    abstract <T> Object  fondo();
    abstract boolean vacia();

}
